# Fisher-Game
Project from JavaScript Developer Professional Program - Course 5 - 04.2022-05.2022 - SoftUni Global

To start the server, run the included start.bat file, or manually open a command prompt and execute the node server.js command.

CRUD operations and a functionality for User Authentication.
