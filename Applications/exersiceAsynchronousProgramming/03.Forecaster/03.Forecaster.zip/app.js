function attachEvents() {
  const input = document.getElementById("location");
  const submitBtn = document.getElementById("submit");
  const forecastDiv = document.getElementById("forecast");
  const currentDiv = document.getElementById("current");
  const upcomingDiv = document.getElementById("upcoming");

  const symbols = {
    Sunny: "&#x2600;", // ☀
    "Partly sunny": "&#x26C5;", // ⛅
    Overcast: "&#x2601;", // ☁
    Rain: "&#x2614;" // ☂
  };

  submitBtn.addEventListener("click", async () => {
    const location = input.value;
    forecastDiv.style.display = "block";
    currentDiv.innerHTML = `<div class="label">Current conditions</div>`;
    upcomingDiv.innerHTML = `<div class="label">Three-day forecast</div>`;

    try {
      // 1. Get location code
      const locRes = await fetch(`http://localhost:3030/jsonstore/forecaster/locations`);
      const locations = await locRes.json();
      const locationObj = locations.find((loc) => loc.name === location);

      if (!locationObj) {
        throw new Error("Location not found");
      }

      const code = locationObj.code;

      // 2. Get today weather
      const todayRes = await fetch(`http://localhost:3030/jsonstore/forecaster/today/${code}`);
      const todayData = await todayRes.json();

      // 3. Get upcoming weather
      const upcomingRes = await fetch(`http://localhost:3030/jsonstore/forecaster/upcoming/${code}`);
      const upcomingData = await upcomingRes.json();

      // 4. Display current weather
      const forecastsDiv = document.createElement("div");
      forecastsDiv.className = "forecasts";

      const symbolSpan = document.createElement("span");
      symbolSpan.className = "condition symbol";
      symbolSpan.innerHTML = symbols[todayData.forecast.condition];

      const conditionSpan = document.createElement("span");
      conditionSpan.className = "condition";
      conditionSpan.innerHTML = `
        <span class="forecast-data">${todayData.name}</span>
        <span class="forecast-data">${todayData.forecast.low}&#176;/${todayData.forecast.high}&#176;</span>
        <span class="forecast-data">${todayData.forecast.condition}</span>`;

      forecastsDiv.appendChild(symbolSpan);
      forecastsDiv.appendChild(conditionSpan);
      currentDiv.appendChild(forecastsDiv);

      // 5. Display 3-day forecast
      const forecastInfo = document.createElement("div");
      forecastInfo.className = "forecast-info";

      upcomingData.forecast.forEach((day) => {
        const upcomingSpan = document.createElement("span");
        upcomingSpan.className = "upcoming";
        upcomingSpan.innerHTML = `
          <span class="symbol">${symbols[day.condition]}</span>
          <span class="forecast-data">${day.low}&#176;/${day.high}&#176;</span>
          <span class="forecast-data">${day.condition}</span>
        `;
        forecastInfo.appendChild(upcomingSpan);
      });

      upcomingDiv.appendChild(forecastInfo);

    } catch (err) {
      forecastDiv.style.display = "block";
      forecastDiv.innerHTML = "Error";
    }
  });
}

attachEvents();
